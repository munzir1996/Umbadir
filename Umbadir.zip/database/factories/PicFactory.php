<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pic;
use Faker\Generator as Faker;

$factory->define(Pic::class, function (Faker $faker) {
    return [
        //
    ];
});
