<!-- BEGIN CORE PLUGINS -->
<script src="<?php echo e(asset('vendor/cpanel/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/js.cookie.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/bootstrap-hover-dropdown.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/bootstrap-switch.min.js')); ?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->

<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?php echo e(asset('vendor/cpanel/js/app.min.js')); ?>" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo e(asset('vendor/cpanel/js/layout.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/demo.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/quick-sidebar.min.js')); ?>" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo e(asset('vendor/cpanel/js/toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/jquery.validate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/additional-methods.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/select2.full.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/filterDropDown.min.js')); ?>" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS  -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo e(asset('vendor/cpanel/js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/cpanel/js/login.min.js')); ?>" type="text/javascript"></script>
<!-- END PAGE LEVEL SCRIPTS -->


<?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/admins/includes/_javascript.blade.php ENDPATH**/ ?>