<?php $__env->startSection('title', 'الصفحة الرئيسية'); ?>

<?php $__env->startSection('content'); ?>
<!-- BEGIN PAGE-BAR -->
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="#">الصفحة الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
</div>
<!-- END PAGE-BAR -->
<!-- BEGIN PAGE TITLE-->
<h3 class="page-title"> لوحة التحكم
    <small>لوحة التحكم &amp; الأحصائيات</small>
</h3>
<!-- END PAGE TITLE-->
<!-- BEGIN DASHBOARD STATS 1-->

<!-- END DASHBOARD STATS 1-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/admin/index.blade.php ENDPATH**/ ?>