<!-- Counter -->
<section class="ftco-counter ftco-intro" id="section-counter">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                <div class="block-18 color-3 align-items-stretch">
                    <div class="text">
                        <h3 class="mb-4">انضم الينا</h3>
                        <p>"و ايد على ايد تجدع بعيد"</p>
                        <p><a href="#" class="btn btn-white px-3 py-2 mt-2">شاركنا</a></p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                <div class="block-18 color-2 align-items-stretch">
                    <div class="text">
                        <h3 class="mb-4">تبرع الان</h3>
                        <p>شاركنا بما تيسر , مد يد العون و احياء للانسانية و تعميرا للبلاد</p>
                        <p><a href="#" class="btn btn-white px-3 py-2 mt-2">تبرع هنا</a></p>
                    </div>
                </div>
            </div>

            <div class="col-md-5 d-flex justify-content-center counter-wrap ftco-animate">
                <div class="block-18 color-1 align-items-stretch">
                    <div class="text">
                        <span>خدمات وصلت الى</span>
                        <strong class="number" data-number="1023900">0</strong>
                        <span>نسمة حول عدة ولايات</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--END Counter-->
<?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/includes/counter.blade.php ENDPATH**/ ?>