<?php $__env->startSection('content'); ?>
<!-- BEGIN PAGE-BAR -->
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="<?php echo e(route('admin')); ?>">الصفحة الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="<?php echo e(route('goals.index')); ?>">goal</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
</div>
<!-- END PAGE-BAR -->

<h3 class="page-title">تعديل goal </h3>

<form action="<?php echo e(route('goals.update', $goal->id)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <label>title</label>
        <input type="text" name="title" class="form-control" value="<?php echo e($goal->title); ?>" required>
    </div>

    <div class="form-group">
        <label>description</label>
        <textarea type="text" name="description" class="form-control" value="<?php echo e($goal->description); ?>" required></textarea>
    </div>

    <!-- IMAGE -->
    <label>صورة</label>
    <div class="fileinput fileinput-new input-group" data-provides="fileinput">
        <div class="form-control" data-trigger="fileinput">
            <i class="glyphicon glyphicon-file fileinput-exists"></i>
            <span class="fileinput-filename"></span>
        </div>
        <span class="input-group-addon btn btn-default btn-file">
            <span class="fileinput-new">Select file</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" id="image" name="image">
        </span>
        <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
    </div>

    <label>Old image</label>
    <div class="form-group">
        <img src="<?php echo e(asset('images/'.$goal->image)); ?>" alt="" srcset="">
    </div>

    <div class="margin-top-10">
        <button type="submit" class="btn green"> حفظ التعديل </button>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/admins/goals/edit.blade.php ENDPATH**/ ?>