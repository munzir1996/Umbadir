<link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Overpass:300,400,400i,600,700" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('vendor/css/open-iconic-bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/aos.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/bootstrap-datepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/jquery.timepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/icomoon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/style.css')); ?>">



<?php /**PATH D:\Projects\Laravel\Umbadir\resources\views/includes/_head.blade.php ENDPATH**/ ?>