<footer class="ftco-footer ftco-section img">
    <div class="overlay"></div>
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-3">
        <div align="center" class="ftco-footer-widget mb-6">
        <p align="center"> Powerd by OmegaTeam</p>
      </div>
    </div>
  </div>
</footer>
<?php /**PATH D:\Projects\Laravel\Umbadir\resources\views/includes/_footer.blade.php ENDPATH**/ ?>