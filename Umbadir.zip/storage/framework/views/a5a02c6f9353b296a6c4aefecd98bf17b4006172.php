<!-- BEGIN FOOTER -->
<div class="page-footer">

    <div class="page-footer-inner">
        2019 &copy <a href="#">Omega Team</a> - All Rights Reserved
    </div>
    <div class="scroll-to-top" style="dispaly: none;">
        <i class="fas fa-angle-up"></i>
    </div>

</div>
<!-- END FOOTER -->
<?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/admin/includes/_footer.blade.php ENDPATH**/ ?>