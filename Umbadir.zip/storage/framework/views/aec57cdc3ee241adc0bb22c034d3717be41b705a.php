<?php $__env->startSection('title', 'project'); ?>
<!-- BEGIN CSS -->
<?php $__env->startSection('stylesheets'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/plugins/datatables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css')); ?>">
<?php $__env->stopSection(); ?>
<!-- END CSS -->

<?php $__env->startSection('content'); ?>
<!-- BEGIN PAGE-BAR -->
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="<?php echo e(route('admin')); ?>">الصفحة الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="<?php echo e(route('projects.index')); ?>">project</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
</div>
<!-- END PAGE-BAR -->

<h3 class="page-title"> project </h3>

<!-- BEGIN DATATABLE -->
<div class="portlet light bordered">
    <div class="portlet-title">
        <div class="caption">
            <i class="icon-social-dribbble font-green"></i>
            <span class="caption-subject font-green bold uppercase">جدول project</span>
        </div>
    </div>
    <div class="portlet-body">
        <div class="table-toolbar">
            <div class="row">
                <div class="col-md-6">
                    <div class="btn-group">
                        <button data-toggle="modal" class="btn sbold green" href="#add_project"> أضافة project
                            <i class="fa fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- BEGIN TABLE -->
        <div class="">
            <table id="projects-table" class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th> # </th>
                        <th>Title</th>
                        <th>العمليات</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($project->id); ?></td>
                        <td><?php echo e($project->title); ?></td>
                        <td>
                            <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo e(method_field('DELETE')); ?>

                                <a href="<?php echo e(route('projects.edit', $project->id)); ?>"
                                    class="btn dark btn-sm btn-outline sbold uppercase">
                                    <i class="fa fa-edit"> تعديل </i>
                                </a>
                                <button type="submit" class="btn red btn-sm btn-outline sbold uppercase">
                                    <i class="fa fa-edit">حذف</i>
                                </button>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END TABLE -->
    </div>
</div>
<!-- END DATATABLE -->

<!-- BEGIN ADD_project MODEL -->
<div class="modal fade in" id="add_project">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add project</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('projects.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>الأسم</label>
                        <input type="text" name="title" class="form-control" placeholder="Title" required>

                        <label>الأسم</label>
                        <textarea type="text" name="description" class="form-control ck_editor" placeholder="Description" required></textarea>

                        <label>صورة</label>
                        <input id="image" type="file" name="image" multiple>

                    </div>
                    <div class="margin-top-10">
                        <button type="submit" class="btn btn-outline sbold green">أضافة</button>
                        <button type="button" class="btn btn-outline sbold red" data-dismiss="modal">أغلاق</button>
                    </div>
                </form>
            </div>


        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- BEGIN ADD_project MODEL -->


<?php $__env->stopSection(); ?>

<!-- BEGIN SCRIPTS -->
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/adminjs/datatable.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/plugins/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')); ?>"></script>
<script>
    //Datatable
    $(document).ready(function () {
        $('#projects-table').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>
<!-- END SCRIPTS -->






<?php echo $__env->make('admins.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/admins/projects/index.blade.php ENDPATH**/ ?>