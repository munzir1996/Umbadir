<script src="<?php echo e(asset('vendor/js/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.timepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/scrollax.min.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="<?php echo e(asset('vendor/js/google-map.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/main.js')); ?>"></script>




<?php /**PATH /home/waffen-ss/Desktop/Projects/Laravel/Umbadir/resources/views/includes/_javascript.blade.php ENDPATH**/ ?>